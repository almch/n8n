import { Signature, signature } from '../signatures';

signature('x') satisfies Signature;
