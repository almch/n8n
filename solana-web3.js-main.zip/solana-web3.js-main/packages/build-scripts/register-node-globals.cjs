globalThis.__DEV__ = false;
globalThis.__BROWSER = false;
globalThis.__NODEJS__ = true;
globalThis.__REACTNATIVE__ = false;
