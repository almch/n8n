---
'@solana/compat': patch
---

updated readme to include instruction compat functions
