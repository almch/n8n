---
'@solana/keys': patch
---

Key operations now work in versions of Firefox that support `Ed25519` natively
