---
'@solana/rpc-api': patch
---

Fix accountKeys type in getTransaction JSON parsed
