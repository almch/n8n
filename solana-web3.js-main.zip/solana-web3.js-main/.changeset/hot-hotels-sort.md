---
'@solana/codecs-data-structures': patch
---

`LiteralUnionCodec` is now exported from `@solana/codecs-data-structures`
