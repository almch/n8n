---
'@solana/rpc-subscriptions': patch
---

The online/offline checker in the subscriptions implementation no longer throws an error when hosted in the Content Scripts environment of a browser extension
